%% The default data set

%% this will replace the data.xlsx file in BEAR folder and the
%% bear_settings.m file in the BEAR\files folder

%% specify data file name:
dataxlsx='data_.xlsx';
%% and the settings file name:
settingsm='bear_settings_.m';
%(and copy both to the replications\data folder)
% then run other preliminaries
runprelim;