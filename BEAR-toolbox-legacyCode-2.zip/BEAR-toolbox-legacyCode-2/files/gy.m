function [val]=gy(x,quant)


% indicator function for quantiles values
% returns 1 if the value 'x' is lower than or equal to the threshold value 'quant'
% returns 0 otherwise


val=x<=quant;


































