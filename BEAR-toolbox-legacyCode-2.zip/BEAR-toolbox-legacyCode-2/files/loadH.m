function[H]=loadH
% load the data from Excel
[H txt]=xlsread('data.xlsx','Long run prior');
end