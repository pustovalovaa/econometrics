function value=lagrange(lambdatilde,pii,G)


value=pii'*exp(G*lambdatilde);
