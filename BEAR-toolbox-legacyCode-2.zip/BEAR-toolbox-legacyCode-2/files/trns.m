function [XT]=trns(X)



XT=X';

